/* ============================================================
   BIBLIOTHÈQUE DE DOCUMENTS : seul fichier à modifier pour ajouter un document.
   - fichier   : chemin du PDF (ex. "assets/documents/certifications/huawei-python.pdf")
                 ou null tant que le fichier n'est pas déposé (« Bientôt disponible »).
   - publie    : false = la carte est cachée sur le site public.
   - format    : "PDF", "PNG"... (« Consulter » seulement pour PDF et images).
   - categorie : une des valeurs de CATEGORIES.
   ============================================================ */
const CATEGORIES=["CV","Rapports de projets","Attestations","Certifications","Présentations"];
const DOCUMENTS=[
{titre:"CV — Abderazzak Fathallah",categorie:"CV",desc:"Parcours, expériences, compétences et certifications.",format:"PDF",fichier:"assets/documents/cv/CV_Fathallah_Abderazzak.pdf",publie:true},
{titre:"Rapport — Smart Classroom & SCADA",categorie:"Rapports de projets",desc:"Projet IoT primé : capteurs, MQTT, Node-RED, supervision.",format:"PDF",fichier:null,publie:true},
{titre:"Rapport — Bras Pro Max",categorie:"Rapports de projets",desc:"Conception 3D SolidWorks, ESP32 et contrôle via Blynk.",format:"PDF",fichier:null,publie:true},
{titre:"Rapport — Robot autonome de transport de granulés",categorie:"Rapports de projets",desc:"Robot mobile autonome, projet primé.",format:"PDF",fichier:null,publie:true},
{titre:"Rapport — CityWind",categorie:"Rapports de projets",desc:"Étude éolienne et dimensionnement mécanique.",format:"PDF",fichier:null,publie:true},
{titre:"Attestation de stage — LEONI",categorie:"Attestations",desc:"Stage de juin à septembre 2026, Bouskoura.",format:"PDF",fichier:null,publie:true},
{titre:"Attestation de stage — Safran Nacelles",categorie:"Attestations",desc:"Stage PFE de septembre 2026 à avril 2027.",format:"PDF",fichier:null,publie:true},
{titre:"Python Programming Basics — Huawei",categorie:"Certifications",desc:"Bases de la programmation Python, décembre 2025.",format:"PDF",fichier:null,publie:true},
{titre:"Business Analysis & Process Management",categorie:"Certifications",desc:"Analyse métier et gestion des processus, novembre 2025.",format:"PDF",fichier:null,publie:true},
{titre:"HiveMQ Certified MQTT Associate",categorie:"Certifications",desc:"Protocole MQTT pour l'IoT, novembre 2025.",format:"PDF",fichier:null,publie:true},
{titre:"TCF — niveau B2",categorie:"Certifications",desc:"Test de connaissance du français, août 2026.",format:"PDF",fichier:null,publie:true},
{titre:"Captures des outils Excel/VBA (anonymisées)",categorie:"Présentations",desc:"Aperçu des outils de suivi, sans données réelles.",format:"PDF",fichier:null,publie:true},
{titre:"Présentations des projets académiques",categorie:"Présentations",desc:"Supports de présentation des quatre projets.",format:"PDF",fichier:null,publie:true}
];
